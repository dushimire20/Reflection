package com.example.refrection7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;

import java.util.ArrayList;
import java.util.List;

public class Recycler extends AppCompatActivity {
    RecyclerView customRecycler;
    RecyclerView.LayoutManager layoutManager;
    List<Item> itemList;
    MyCustomAdapter myCustomAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
        customRecycler = findViewById(R.id.CustRecycler);
        layoutManager = new LinearLayoutManager(this);
        customRecycler.setLayoutManager(layoutManager);
        itemList=new ArrayList<>();
        itemList=fillTheList();
        myCustomAdapter=new MyCustomAdapter(this,itemList);
        customRecycler.setAdapter(myCustomAdapter);

    }

    private List<Item> fillTheList() {

        List<Item> itemList = new ArrayList<>();
        itemList.add(new Item(R.drawable.steven,"Steven Iyera", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.oscar,"Dushimire Oscar Napoleon", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.manzi,"Ineza Manzi Gandhi", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.judith,"Mushimiyimana Judith", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.lionel,"Jean Lionel Ndabaga", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.yvan,"Yvan Nshuti", "Information System","24 years old", "95 grades"));
        itemList.add(new Item(R.drawable.santus,"Niyonkuru Santus", "Information System","24 years old", "95 grades"));
        return itemList;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mymenu,menu);
        return true;
    }
}