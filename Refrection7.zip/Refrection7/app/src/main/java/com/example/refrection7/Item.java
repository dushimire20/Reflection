package com.example.refrection7;

public class Item {
    int itemImage;
    String itemName;
    String itemDepartment;
    String itemAge;
    String itemGrade;

    public Item(int itemImage, String itemName, String itemDepartment, String itemAge, String itemGrade) {
        this.itemImage = itemImage;
        this.itemName = itemName;
        this.itemDepartment = itemDepartment;
        this.itemAge = itemAge;
        this.itemGrade = itemGrade;
    }

    public int getItemImage() {
        return itemImage;
    }

    public void setItemImage(int itemImage) {
        this.itemImage = itemImage;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemDepartment() {
        return itemDepartment;
    }

    public void setItemDepartment(String itemDepartment) {
        this.itemDepartment = itemDepartment;
    }

    public String getItemAge() {
        return itemAge;
    }

    public void setItemAge(String itemAge) {
        this.itemAge = itemAge;
    }

    public String getItemGrade() {
        return itemGrade;
    }

    public void setItemGrade(String itemGrade) {
        this.itemGrade = itemGrade;
    }
}
