package com.example.refrection7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mymenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuView:


                startActivity(new Intent(MainActivity.this, Recycler.class));
                break;
            case R.id.menuLogin:
                //
                break;
            case R.id.menuSignUp:
                Toast.makeText(this, "Selected Add", Toast.LENGTH_SHORT).show();
                callMyCustomDialog();

                break;
            case R.id.menuGrades:
                //
                break;
            case R.id.menuPeople:
                //
                break;
            case R.id.menuAnnounce:
                //
        }
        return super.onOptionsItemSelected(item);
    }

    //function to fill dialog box

    private void callMyCustomDialog() {

        MaterialAlertDialogBuilder myDialog = new MaterialAlertDialogBuilder(this);
        // Inflate our own view dialog
        LayoutInflater layoutInflater = getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.custom_dialog, null);
        //Referencing our textinput
        TextInputEditText etName= view.findViewById(R.id.etNames);
        TextInputEditText etEmail = view.findViewById(R.id.etEmail);
        TextInputEditText etFaculty = view.findViewById(R.id.etFaculty);
        TextInputEditText etPassword = view.findViewById(R.id.etPassword);
        TextInputEditText etRePassword = view.findViewById(R.id.etRePassword);

        myDialog.setView(view);
      /*  myDialog.setTitle("You are Going to Sign up");
        myDialog.setMessage("Please make sure the information you provided are correct and valid");*/
        myDialog.setPositiveButton("Send", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                Toast.makeText(MainActivity.this, " Information Saved: " + etName.getText().toString()+" \n " + etEmail + "\n" + etFaculty + "\n" + etPassword, Toast.LENGTH_SHORT).show();

            }
        });

        myDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

        myDialog.setCancelable(false);
        myDialog.show();
    }

}

